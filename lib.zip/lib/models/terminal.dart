// models/terminal.dart
import 'package:mapbox_gl/mapbox_gl.dart';

class Terminal {
  final String name;
  final List<LatLng> points;
  final String iconImage;
  final List<Route> routes;

  Terminal({
    required this.name,
    required this.points,
    required this.iconImage,
    required this.routes,
  });
}

class Route {
  final String name;
  final List<LatLng> points;
  final String color;

  Route({
    required this.name,
    required this.points,
    required this.color,
  });
}

final List<Terminal> terminals = [
  Terminal(
    name: 'Muzon - Tungkong Mangga Terminal',
    points: [LatLng(14.796411, 121.0287)],
    iconImage: 'jeepejeep.png',
    routes: [
      Route(
        name: 'Route 1',
        points: [
                LatLng(14.796411, 121.0287),
                LatLng(14.791351, 121.07125),
                LatLng(14.787361, 121.070373),
                LatLng(14.786498, 121.069463),
                LatLng(14.785011, 121.069507),
                LatLng(14.785032, 121.074446),
                LatLng(14.786524, 121.074784),
                LatLng(14.789037, 121.074708),
                LatLng(14.788986, 121.075435),
                LatLng(14.789702, 121.075188),
                ],
        color: '#ff0000',
      ),
      Route(
        name: 'Route 2',
        points: [/* list of points */],
        color: '#00ff00',
      ),
    ],
  ),
  // Add more terminals as needed
];