import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:mapbox_gl/mapbox_gl.dart';
import '../services/map_controller.dart';

class MapPage extends StatefulWidget {
  @override
  _MapPageState createState() => _MapPageState();
}

class _MapPageState extends State<MapPage> {
  final MapController _mapController = MapController();
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  @override
void initState() {
  super.initState();
  _mapController.initializeLocationService();
  _mapController.addListener(() {
    if (_mapController.selectedTerminal != null) {
      _openRouteDrawer();
    }
  });
}

  @override
Widget build(BuildContext context) {
  return FutureBuilder<Position>(
    future: _mapController.positionFuture,
    builder: (context, snapshot) {
      if (snapshot.connectionState == ConnectionState.waiting) {
        return Center(child: CircularProgressIndicator()); // Loading indicator
      } else if (snapshot.hasError) {
        return Center(child: Text('Error fetching location'));
      } else if (!snapshot.hasData || snapshot.data == null) {
        return Center(child: Text('Location data not available'));
      }

      Position position = snapshot.data!;
      return Scaffold(
        key: _scaffoldKey,
        appBar: AppBar(
          title: Text('Map Routing'),
          actions: [
            IconButton(
              icon: Icon(Icons.directions),
              onPressed: _mapController.enableRouting,
            ),
          ],
        ),
        body: Stack(
          children: [
            MapboxMap(
              accessToken: 'pk.eyJ1IjoicmVpamkyMDAyIiwiYSI6ImNsdnV6c2hhZzFxZTAybG1oMzJoeDNtOGQifQ.0hCQ02IhCilBVh-DhFDioQ',
              onMapCreated: _mapController.onMapCreated,
              onStyleLoadedCallback: _mapController.onStyleLoaded,
              initialCameraPosition: CameraPosition(
                target: LatLng(position.latitude, position.longitude),
                zoom: 14.0,
              ),
              onMapClick: ((point, coordinates) => _mapController.onMapClick(coordinates)),
              myLocationEnabled: true,
              myLocationTrackingMode: MyLocationTrackingMode.Tracking,
            ),
            if (_mapController.styleLoaded)
              Positioned(
                bottom: 10,
                left: 10,
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text('Info Window Placeholder'),
                  ),
                ),
              ),
          ],
        ),
        drawer: _buildRouteDrawer(), // Left-side drawer
      );
    },
  );
}


void _openRouteDrawer() {
  final terminal = _mapController.selectedTerminal;

  if (terminal != null) {
    print('Selected Terminal: ${terminal.name}');
    print('Number of Routes: ${terminal.routes.length}');
    for (var route in terminal.routes) {
      print('Route: ${route.name}');
    }

    // Use a delay to ensure the frame has rendered before opening the drawer
    Future.delayed(Duration(milliseconds: 100), () {
      _scaffoldKey.currentState?.openDrawer();
      print("Drawer should open now.");
    });
  } else {
    print('No Terminal Selected');
  }
}

  Widget _buildRouteDrawer() {
  final terminal = _mapController.selectedTerminal;
  
  if (terminal == null || terminal.routes.isEmpty) {
    return Drawer(
      child: Center(child: Text('No routes available')),
    );
  }

  return Drawer(
    child: ListView.builder(
      itemCount: terminal.routes.length,
      itemBuilder: (context, index) {
        final route = terminal.routes[index];
        return ListTile(
          title: Text(route.name),
          onTap: () {
            Navigator.pop(context);
            _mapController.displayRoute(route);
          },
        );
      },
    ),
  );
}
}
